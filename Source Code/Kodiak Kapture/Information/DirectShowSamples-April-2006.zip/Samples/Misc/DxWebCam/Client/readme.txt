---------------------------------------------------------------------
WebCamClient

While the underlying libraries are covered by LGPL, this sample is released 
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  

---------------------------------------------------------------------

A poor man's web cam program. This application runs as a Win32 Service.  
It takes the output of a capture graph, turns it into a stream of JPEG 
files, and sends it thru TCP/IP to a client application.