---------------------------------------------------------------------
A small toolkit library

While the underlying libraries are covered by LGPL, this sample is released 
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  

---------------------------------------------------------------------

This sample is a collection of helper methods for the DirectShow FilterGraph
provided as a .Net class library.

You can use it in your own works by 
	- compile it and reference it in your project
	- just add the FilterGraphTools.cs file in your project
	- take just interesting parts

Documentation is available in the "doc" folder.