---------------------------------------------------------------------
DxPlay

While the underlying libraries are covered by LGPL, this sample is released 
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  

---------------------------------------------------------------------

A sample application showing how to play media files (AVI, WMV, etc) and 
capture snapshots.

Note, this sample is primarily meant to show building the graph and capturing
frames.  It does NOT connect the audio pin.