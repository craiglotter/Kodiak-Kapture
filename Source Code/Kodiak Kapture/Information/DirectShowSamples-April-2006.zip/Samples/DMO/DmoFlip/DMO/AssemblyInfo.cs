using System.Reflection;
using System.Runtime.CompilerServices;

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle("DmoFlip")]
[assembly: AssemblyDescription("A DMO sample to flip video")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("http://DirectShowNet.SourceForge.net")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Public Domain")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		

[assembly: AssemblyVersion("1.0.0.0")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyName("")]
