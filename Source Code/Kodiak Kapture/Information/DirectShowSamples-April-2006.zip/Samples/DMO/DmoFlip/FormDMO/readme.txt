FormDmo - This code exercises the DMOFlip sample code.

This rather simple-minded example shows how to build a graph using a DMO.  It also reads 
and sets the DMOFlip mode parameter, and reads parameter info (outputting the results with 
Debug.WriteLine).