There are several readme's with this project.  In addition to this file, there is a 
readme in both the DMO and the FormDmo folders.

The readme in the DmoForm folder talks about calling DMOs.  The readme in the DMO 
folder talks about the specific sample.

There are detailed steps in the IMediaObjectImpl.chm talking about how to make a DMO.  In particular,
you should look at the "IMediaObjectImpl Class" page in the file which provides step by step instructions
on how to write a DMO.

For people who have never written a COM object, you may find the article at 
http://community.borland.com/article/0,1410,32754,00.html to be informative.