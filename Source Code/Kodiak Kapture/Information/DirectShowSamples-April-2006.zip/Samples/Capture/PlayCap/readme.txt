---------------------------------------------------------------------
PlayCap

While the underlying libraries are covered by LGPL, this sample is released 
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  

---------------------------------------------------------------------

A translation of the DirectShow PlayCap program to show how this would
appear in c#.

This application creates a preview window for the first video capture device 
that it locates on the user's system (if any). It demonstrates a simple 
example of using the ICaptureGraphBuilder2 and ICreateDevEnum interfaces 
to build a capture graph.

