/************************************************************************
DxLogoVB - VB version of DxLogo sample

While the underlying libraries are covered by LGPL, this sample is released 
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  

**************************************************************************/

This is precisely the same sample as DxLogo, except that it's written 
in VB. Other than the tediousness of converting C# to VB, this was a 
trivial exercise. No changes were required in the library code.